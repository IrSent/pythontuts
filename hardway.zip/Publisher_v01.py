#-*- coding:utf-8 -*-
#
#	GoodSenya
#
#	Only "choose file" for now, next time - drag'n'drop
#

import Tkinter, Tkconstants, tkFileDialog

class TkFileDialogExample(Tkinter.Frame):

  def __init__(self, root):

    Tkinter.Frame.__init__(self, root)

    # options for buttons
    button_opt = {'fill': Tkconstants.BOTH, 'padx': 5, 'pady': 5}


	
    
    # define buttons
    #Tkinter.Button(self, text='askopenfile', command=self.askopenfile).pack(**button_opt)
    #Tkinter.Button(self, text='askopenfilename', command=self.askopenfilename).pack(**button_opt)

    # define options for opening or saving a file
    self.file_opt = options = {}
    options['defaultextension'] = '.png', '.jpg'
    options['filetypes'] = [('jpg', '.jpg'), ('png', '.png')]
    options['parent'] = root
    options['title'] = 'This is a title'

    # This is only available on the Macintosh, and only when Navigation Services are installed.
    #options['message'] = 'message'

    # if you use the multiple file version of the module functions this option is set automatically.
    #options['multiple'] = 1

    # defining options for opening a directory
    self.dir_opt = options = {}
    options['initialdir'] = 'C:\\'
    options['mustexist'] = False
    options['parent'] = root
    options['title'] = 'This is a title'

  def askopenfile(self):

    """Returns an opened file in read mode."""

    return tkFileDialog.askopenfile(mode='r', **self.file_opt)

  def askopenfilename(self):

    """Returns an opened file in read mode.
    This time the dialog just returns a filename and the file is opened by your own code.
    """

    # get filename
    filename = tkFileDialog.askopenfilename(**self.file_opt)

    # open file on your own
    if filename:
      return open(filename, 'r')

if __name__=='__main__':
  root = Tkinter.Tk()
  idLabel = Tkinter.Label(root,text="AppID:")
  idLabel.grid(row = 0, column = 0, sticky = W, padx = 5, pady = 5)

  idEntry = Tkinter.Entry(root, width=20)
  idEntry.grid(row = 0, column = 1, sticky = W, padx = 5, pady = 5)

  iosScreenPath = Tkinter.Button(self, text='askopenfilename', command=self.askopenfilename)
  androidScreenPath = Tkinter.Button(self, text='askopenfilename', command=self.askopenfilename)
  
  root.mainloop()

