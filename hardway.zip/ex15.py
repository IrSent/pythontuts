from sys import argv # импортировать поддержку аргументов в скрипт

script, filename = argv # название файла + запис. аргумент

txt = open(filename) # в тхт записать открытие файла с назв файлнейм

print "Your file %r:" % filename # вывод назв файла
print txt.read() # прочитать содержимое файла
# тоже самое, что и open(filename).read() ?????

print "Type the filename again:"
file_again = raw_input("> ") # промт к вооду строки

txt_again = open(file_again)

print txt_again.read()