# - *- coding: utf- 8 - *-

print "I'm new to python"
print "Let's do it!"
print "I want to earn money with that kind of work."

print "Получится ли?"
print "ПОЛУЧИЛОСЬ!"
print 'РаБоТаеТ'
print 'Holy craaaap!'