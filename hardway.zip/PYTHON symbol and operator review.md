PYTHON symbol and operator review

Keywords:
			and, or, not	-	logical operation conditionals
													
			del 			-	delete things (dicts, lists, vars oth)
													
			from 	____	import	____	as 	____
							-	the way you import modules
													
			while			-	loop
			
			if, elif, else 	-	parts of the if-statement

			global			-	useful to change or create global variables in a local context.
													
	////	with
													
			assert			-	convenient way to insert debugging assertions into a program
													
			pass			-	It is used when a statement is required syntactically but you do not want any command or code to execute.
													
			yield
													
			break

			except
			
			print
													
			class
													
			exec
													
			in
													
			raise
													
			continue
													
			finally
													
			is
			
			return
			
			def
			
			for
			
			lambda
			
			try

Data Types

			True

			False

			None

			strings

			numbers

			floats

			lists

String Escape Sequences
													
			\\
			
			\'
			
			\"
													
													\a
													
													\b
													
													\f
													
													\n
													
													\r
													
													\t
													
													\v

String Formats
													
													%d
													
													%i
													
													%o
													
													%u
													
													%x
													
													%X
													
													%e
													
													%E
													
													%f
													
													%F
													
													%g
													
													%G
													
													%c
													
													%r
													
													%s
													
													%%

Operators

													
													+
													
													-
													
													*
													
													**
													
													/
													
													//
													
													%
													
													<
													
													>
													
													<=
													
													>=
													
													==
													
													!=
													
													<>
													
													( )
													
													[ ]
													
													{ }
													
													@
													
													,
													
													:
													
													.
													
													=
													
													;
													
													+=
													
													- =
													
													*=
													
													/=
													
													//=
													
													%=
													
													**=